<template>
  <div class="container">
    <div class="center">
      <b-card
        title="regist Question"
        img-src="https://picsum.photos/600/300/?image=20"
        img-alt="Image"
        img-top
        tag="article"
        style="max-width: 30rem"
        class="mb-2"
      >
        <b-card-text> 글 등록을 하러 가는 페이지입니다. </b-card-text>

        <b-button href="#" variant="primary"
          ><router-link :to="{ name: 'BoardWrite' }" class="white"
            >글 등록하러 가기</router-link
          ></b-button
        >
      </b-card>
      <b-card
        title="Question List"
        img-src="https://picsum.photos/600/300/?image=4"
        img-alt="Image"
        img-top
        tag="article"
        style="max-width: 30rem"
        class="mb-2"
      >
        <b-card-text> 글 목록 페이지 입니다. </b-card-text>

        <b-button variant="primary"
          ><router-link :to="{ name: 'BoardWrite' }" class="white"
            >글 목록 보러 가기</router-link
          ></b-button
        >
      </b-card>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Main',
  props: {
    msg: String,
  },
}
</script>

<style>
.container {
  margin: auto 0;
  width: 1200px;
}
.center {
  align-content: center;
  display: flex;
  justify-content: space-between;
}

.white {
  color: #fff;
}
</style>
