<template>
  <div class="container">
    <h2>Vuejs를 이용한 게시판입니다.</h2>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>